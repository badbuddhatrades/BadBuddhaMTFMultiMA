#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private BadBuddhaMTFMultiMA[] cacheBadBuddhaMTFMultiMA;

		
		public BadBuddhaMTFMultiMA BadBuddhaMTFMultiMA(bool enableUpdateCheck, bool showUpdatePopup, TimeFrameOption higherTimeFrame, MAType mA1Type, int period1, MAType mA2Type, int period2, MAType mA3Type, int period3, MAType mA4Type, int period4)
		{
			return BadBuddhaMTFMultiMA(Input, enableUpdateCheck, showUpdatePopup, higherTimeFrame, mA1Type, period1, mA2Type, period2, mA3Type, period3, mA4Type, period4);
		}


		
		public BadBuddhaMTFMultiMA BadBuddhaMTFMultiMA(ISeries<double> input, bool enableUpdateCheck, bool showUpdatePopup, TimeFrameOption higherTimeFrame, MAType mA1Type, int period1, MAType mA2Type, int period2, MAType mA3Type, int period3, MAType mA4Type, int period4)
		{
			if (cacheBadBuddhaMTFMultiMA != null)
				for (int idx = 0; idx < cacheBadBuddhaMTFMultiMA.Length; idx++)
					if (cacheBadBuddhaMTFMultiMA[idx].EnableUpdateCheck == enableUpdateCheck && cacheBadBuddhaMTFMultiMA[idx].ShowUpdatePopup == showUpdatePopup && cacheBadBuddhaMTFMultiMA[idx].HigherTimeFrame == higherTimeFrame && cacheBadBuddhaMTFMultiMA[idx].MA1Type == mA1Type && cacheBadBuddhaMTFMultiMA[idx].Period1 == period1 && cacheBadBuddhaMTFMultiMA[idx].MA2Type == mA2Type && cacheBadBuddhaMTFMultiMA[idx].Period2 == period2 && cacheBadBuddhaMTFMultiMA[idx].MA3Type == mA3Type && cacheBadBuddhaMTFMultiMA[idx].Period3 == period3 && cacheBadBuddhaMTFMultiMA[idx].MA4Type == mA4Type && cacheBadBuddhaMTFMultiMA[idx].Period4 == period4 && cacheBadBuddhaMTFMultiMA[idx].EqualsInput(input))
						return cacheBadBuddhaMTFMultiMA[idx];
			return CacheIndicator<BadBuddhaMTFMultiMA>(new BadBuddhaMTFMultiMA(){ EnableUpdateCheck = enableUpdateCheck, ShowUpdatePopup = showUpdatePopup, HigherTimeFrame = higherTimeFrame, MA1Type = mA1Type, Period1 = period1, MA2Type = mA2Type, Period2 = period2, MA3Type = mA3Type, Period3 = period3, MA4Type = mA4Type, Period4 = period4 }, input, ref cacheBadBuddhaMTFMultiMA);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.BadBuddhaMTFMultiMA BadBuddhaMTFMultiMA(bool enableUpdateCheck, bool showUpdatePopup, TimeFrameOption higherTimeFrame, MAType mA1Type, int period1, MAType mA2Type, int period2, MAType mA3Type, int period3, MAType mA4Type, int period4)
		{
			return indicator.BadBuddhaMTFMultiMA(Input, enableUpdateCheck, showUpdatePopup, higherTimeFrame, mA1Type, period1, mA2Type, period2, mA3Type, period3, mA4Type, period4);
		}


		
		public Indicators.BadBuddhaMTFMultiMA BadBuddhaMTFMultiMA(ISeries<double> input , bool enableUpdateCheck, bool showUpdatePopup, TimeFrameOption higherTimeFrame, MAType mA1Type, int period1, MAType mA2Type, int period2, MAType mA3Type, int period3, MAType mA4Type, int period4)
		{
			return indicator.BadBuddhaMTFMultiMA(input, enableUpdateCheck, showUpdatePopup, higherTimeFrame, mA1Type, period1, mA2Type, period2, mA3Type, period3, mA4Type, period4);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.BadBuddhaMTFMultiMA BadBuddhaMTFMultiMA(bool enableUpdateCheck, bool showUpdatePopup, TimeFrameOption higherTimeFrame, MAType mA1Type, int period1, MAType mA2Type, int period2, MAType mA3Type, int period3, MAType mA4Type, int period4)
		{
			return indicator.BadBuddhaMTFMultiMA(Input, enableUpdateCheck, showUpdatePopup, higherTimeFrame, mA1Type, period1, mA2Type, period2, mA3Type, period3, mA4Type, period4);
		}


		
		public Indicators.BadBuddhaMTFMultiMA BadBuddhaMTFMultiMA(ISeries<double> input , bool enableUpdateCheck, bool showUpdatePopup, TimeFrameOption higherTimeFrame, MAType mA1Type, int period1, MAType mA2Type, int period2, MAType mA3Type, int period3, MAType mA4Type, int period4)
		{
			return indicator.BadBuddhaMTFMultiMA(input, enableUpdateCheck, showUpdatePopup, higherTimeFrame, mA1Type, period1, mA2Type, period2, mA3Type, period3, mA4Type, period4);
		}

	}
}

#endregion
